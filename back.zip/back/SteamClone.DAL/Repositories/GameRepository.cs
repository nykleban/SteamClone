using Microsoft.EntityFrameworkCore;
using SteamClone.DAL;
using SteamClone.DAL.Entities;
using SteamClone.DAL.Repositories;

namespace SPR411_SteamClone.DAL.Repositories
{
    public class GameRepository : GenericRepository<GameEntity>
    {
        private readonly AppDbContext _context;

        public GameRepository(AppDbContext context) : base(context)
        {
            _context = context;
        }

        public IQueryable<GameEntity> Games => GetAll();

        public IQueryable<GameEntity> GetCheaperThan(decimal price)
        {
            return _context.Games.AsNoTracking().Where(g => g.Price < price);
        }

        public IQueryable<GameEntity> GetByGenre(int genreId)
        {
            return _context.Games.AsNoTracking().Where(g => g.Genres.Any(game => game.Id == genreId));
        }
    }
}
